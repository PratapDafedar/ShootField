// (c)2011 MuchDifferent. All Rights Reserved.

using UnityEngine;
//using uLink;

[AddComponentMenu("uLink Utilities/Smooth Platformer")]
public class uLinkSmoothPlatformer : MonoBehaviour
{
	// TODO: not available yet - please use uLinkSmoothCharacter instead
}
